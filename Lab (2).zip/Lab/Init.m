initA1Pos = [150,350];
initA1V = [0,0];
p1_dot_vf=0;
p1_dot_lambda=0;

initA2Pos = [270,200];
initA2V = [0,0];
p2_dot_vf=0;
p2_dot_lambda=0;

initA3Pos = [270,500];
initA3V = [0,0];
p3_dot_vf=0;
p3_dot_lambda=0;

initA4Pos = [420,350];
initA4V = [0,0];
p4_dot_vf=0;
p4_dot_lambda=0;

% B队
initB1Pos = [950,350];
initB1V = [0,0];
p5_dot_vf=0;
p5_dot_lambda=0;

initB2Pos = [830,200];
initB2V = [0,0];
p6_dot_vf=0;
p6_dot_lambda=0;


initB3Pos = [830,500];
initB3V = [0,0];
p7_dot_vf=0;
p7_dot_lambda=0;

initB4Pos = [680,350];
initB4V = [0,0];
p8_dot_vf=0;
p8_dot_lambda=0;

initBallPos = [550,350];
initBallV = [0,0];

hold on


